const express = require('express');
const app = express();
const fs = require('fs');
const cors = require('cors');
const path = require('path');

// Necessário para extrair os dados de Forms vindos de uma requisição POST
app.use(express.json());
app.use(cors());

app.listen(3000, () => {
    console.log('Servidor na porta 3000');
});

// Rota de login
app.post('/login', (req, res) => {
    const { email, senha } = req.body;
    fs.readFile(path.join(__dirname, 'db', 'banco-dados-usuario.json'), 'utf-8', (err, data) => {
        if (err) return res.status(500).send('Erro ao acessar o banco de dados');

        const usuarios = JSON.parse(data);
        const usuario = usuarios.find(u => u.email === email);

        if (!usuario) {
            return res.status(404).send(`Usuario com email ${email} não existe. Considere criar uma conta!`);
        }

        if (usuario.senha !== senha) {
            return res.status(401).send('Usuario ou senhas incorretas.');
        }

        res.send('Autenticado com Sucesso');
    });
});

// Rota de criação de usuário
app.post('/create', (req, res) => {
    const { email, senha } = req.body;
    fs.readFile(path.join(__dirname, 'db', 'banco-dados-usuario.json'), 'utf-8', (err, data) => {
        if (err) return res.status(500).send('Erro ao acessar o banco de dados');

        const usuarios = JSON.parse(data);
        if (usuarios.some(u => u.email === email)) {
            return res.status(409).send(`Usuario com email ${email} já existe.`);
        }

        const novoUsuario = { id: usuarios.length + 1, email, senha };
        const express = require('express');
        const app = express();
        const fs = require('fs');
        const cors = require('cors');
        const path = require('path');
        
        //Necessário para extrair os dados de Forms vindos de uma requisição POST
        app.use(express.json());
        app.use(cors());
        
        
        app.listen(3000, () => {
            console.log('Servidor na porta 3000');
        });
        
        
        usuarios.push(novoUsuario);

        fs.writeFile(path.join(__dirname, 'db', 'banco-dados-usuario.json'), JSON.stringify(usuarios), (err) => {
            if (err) return res.status(500).send('Erro ao salvar o usuário');
            res.send('Tudo certo usuario criado com sucesso.');
        });
    });
});

// Rota para listar todos os cursos
app.get('/cursos', (req, res) => {
    fs.readFile(path.join(__dirname, 'db', 'cursos.json'), 'utf-8', (err, data) => {
        if (err) return res.status(500).send('Erro ao acessar o banco de dados');
        res.json(JSON.parse(data));
    });
});

// Rota para buscar cursos por nome
app.get('/cursos/:nome', (req, res) => {
    const nome = req.params.nome.toLowerCase();
    fs.readFile(path.join(__dirname, 'db', 'cursos.json'), 'utf-8', (err, data) => {
        if (err) return res.status(500).send('Erro ao acessar o banco de dados');

        const cursos = JSON.parse(data).filter(curso => curso.nome.toLowerCase().includes(nome));
        if (cursos.length === 0) {
            return res.status(404).send('Curso Não Encontrado!');
        }

        res.json(cursos);
    });
});
